#pragma once

#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl11ext/types.h>
#include <glbinding/gl11ext/boolean.h>
#include <glbinding/gl11ext/values.h>
#include <glbinding/gl11ext/bitfield.h>
#include <glbinding/gl11ext/enum.h>
#include <glbinding/gl11ext/functions.h>
