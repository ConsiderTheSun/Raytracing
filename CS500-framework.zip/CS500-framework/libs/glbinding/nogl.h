#ifdef __gl_h_
#error "glbinding is not compatible with gl.h"
#endif
