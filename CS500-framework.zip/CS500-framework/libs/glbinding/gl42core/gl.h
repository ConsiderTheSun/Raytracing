#pragma once

#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl42core/types.h>
#include <glbinding/gl42core/boolean.h>
#include <glbinding/gl42core/values.h>
#include <glbinding/gl42core/bitfield.h>
#include <glbinding/gl42core/enum.h>
#include <glbinding/gl42core/functions.h>
