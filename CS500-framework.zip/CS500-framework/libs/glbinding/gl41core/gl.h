#pragma once

#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl41core/types.h>
#include <glbinding/gl41core/boolean.h>
#include <glbinding/gl41core/values.h>
#include <glbinding/gl41core/bitfield.h>
#include <glbinding/gl41core/enum.h>
#include <glbinding/gl41core/functions.h>
